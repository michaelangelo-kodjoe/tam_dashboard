(() => {
  "use strict";

  const API = "/api";
  const ROUTE = "/bams/config";
  const ROOT_ID = "map-root";
  const operatorLabels = {
    ">": "Above threshold",
    ">=": "At or above threshold",
    "<": "Below threshold",
    "<=": "At or below threshold",
  };
  const operatorGlyph = { ">": "↑", ">=": "↑", "<": "↓", "<=": "↓" };

  const state = {
    catalog: [],
    policies: [],
    loading: false,
    saving: false,
    error: "",
    success: "",
    editing: null,
    advancedVisible: false,
  };

  const esc = (v) => String(v ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");

  function apiError(data, status) {
    if (data?.message) return data.message;
    if (data?.error?.message) return data.error.message;
    if (typeof data?.error === "string") return data.error;
    if (data?.fields) {
      const first = Object.values(data.fields)[0];
      if (first) return String(first);
    }
    return `Request failed (${status}).`;
  }

  async function api(path, options = {}) {
    const headers = { ...(options.body ? { "Content-Type": "application/json" } : {}), ...(options.headers || {}) };
    const res = await fetch(`${API}${path}`, { cache: "no-store", ...options, headers });
    let data = null;
    try { data = await res.json(); } catch (_) { /* no body */ }
    if (!res.ok || data?.ok === false) throw new Error(apiError(data, res.status));
    return data || {};
  }

  function isConfigPage() {
    return window.location.pathname === ROUTE || window.location.pathname.endsWith(ROUTE);
  }

  function findPage() {
    if (!isConfigPage()) return null;
    const pages = [...document.querySelectorAll(".page.bm-page")];
    return pages.find((page) => /Alert configuration/i.test(page.textContent || "")) || null;
  }

  function findLegacyPanel(page) {
    return [...page.querySelectorAll(".panel__title")]
      .find((node) => node.textContent.trim() === "Starter templates")
      ?.closest(".panel") || null;
  }

  function exactMetric(name) {
    const q = String(name || "").trim().toLowerCase();
    return state.catalog.find((m) => m.metric_name.toLowerCase() === q) || null;
  }

  function isPattern(value) {
    return /[*?\[]/.test(String(value || ""));
  }

  function policyName(metric, op, threshold, severity) {
    return `${metric} · ${op} ${threshold} · ${severity}`;
  }

  function conditionText(p) {
    return `${operatorLabels[p.operator] || p.operator} ${p.threshold ?? "—"}`;
  }

  function statusBadge(p) {
    if (!p.enabled) return '<span class="map-badge map-badge--off">Disabled</span>';
    return '<span class="map-badge map-badge--on">Auto-applies</span>';
  }

  function severityClass(sev) {
    return sev === "Critical" ? "map-sev--critical" : sev === "Warning" ? "map-sev--warning" : "map-sev--info";
  }

  function render() {
    const page = findPage();
    if (!page) return;
    let root = document.getElementById(ROOT_ID);
    if (!root) {
      root = document.createElement("section");
      root.id = ROOT_ID;
      const split = page.querySelector(".bm-split");
      if (split) page.insertBefore(root, split);
      else page.appendChild(root);
    }

    const legacy = findLegacyPanel(page);
    if (legacy) {
      legacy.dataset.metricPolicyLegacy = "true";
      legacy.hidden = !state.advancedVisible;
    }

    const current = state.editing || {};
    const metric = current.metric_match || "";
    const catalogMetric = exactMetric(metric);
    const op = current.operator || ">";
    const threshold = current.threshold ?? "";
    const severity = current.severity || "Warning";
    const consecutive = current.consecutive_updates ?? 1;
    const cooldown = current.cooldown_minutes ?? 15;
    const enabled = current.enabled !== false;

    const options = state.catalog.map((m) => `<option value="${esc(m.metric_name)}"></option>`).join("");
    const policies = state.policies.filter((p) => p.auto_apply);
    const metricSummary = catalogMetric
      ? `${catalogMetric.appliance_count} ${catalogMetric.appliance_count === 1 ? "appliance" : "appliances"} · ${catalogMetric.account_count} ${catalogMetric.account_count === 1 ? "account" : "accounts"}`
      : metric ? "Choose an exact metric from the catalog." : "Select a metric to see its scope.";
    const preview = metric && threshold !== ""
      ? `${metric} ${op} ${threshold} · ${severity} · ${consecutive} ${Number(consecutive) === 1 ? "update" : "updates"}`
      : "Choose a metric, condition and threshold.";

    root.innerHTML = `
      <div class="map-panel">
        <div class="map-head">
          <div>
            <div class="map-eyebrow">GLOBAL METRIC POLICIES</div>
            <h2>Apply alerts by metric</h2>
            <p>Define the condition once. Every enabled appliance carrying that metric inherits the rule now and in the future.</p>
          </div>
          <div class="map-head__right">
            <span class="map-count">${policies.length} active ${policies.length === 1 ? "policy" : "policies"}</span>
            <button type="button" class="map-btn map-btn--ghost" data-action="toggle-advanced">${state.advancedVisible ? "Hide" : "Show"} advanced templates</button>
          </div>
        </div>

        ${state.error ? `<div class="map-banner map-banner--error" role="alert">${esc(state.error)}</div>` : ""}
        ${state.success ? `<div class="map-banner map-banner--success" role="status">${esc(state.success)}</div>` : ""}

        <div class="map-workbench">
          <form id="map-policy-form" class="map-form" novalidate>
            <div class="map-form__title">
              <span>${state.editing ? "Edit metric policy" : "New metric policy"}</span>
              ${state.editing ? '<button type="button" class="map-link" data-action="cancel-edit">Cancel edit</button>' : ""}
            </div>

            <label class="map-field map-field--wide">
              <span class="map-label">Metric</span>
              <input id="map-metric" class="map-input" list="map-metric-options" autocomplete="off" placeholder="Type to search metrics" value="${esc(metric)}" ${state.editing && isPattern(metric) ? "disabled" : ""} />
              <datalist id="map-metric-options">${options}</datalist>
              <span class="map-hint" id="map-metric-scope">${esc(metricSummary)}</span>
            </label>

            <fieldset class="map-direction">
              <legend class="map-label">Alert when</legend>
              <div class="map-direction__grid">
                ${Object.entries(operatorLabels).map(([value, label]) => `
                  <label class="map-direction__option ${op === value ? "is-on" : ""}">
                    <input type="radio" name="map-operator" value="${value}" ${op === value ? "checked" : ""} />
                    <span class="map-direction__glyph">${operatorGlyph[value]}</span>
                    <span><b>${label}</b><small>${value}</small></span>
                  </label>`).join("")}
              </div>
            </fieldset>

            <label class="map-field">
              <span class="map-label">Threshold</span>
              <input id="map-threshold" class="map-input map-num" type="number" step="any" inputmode="decimal" value="${esc(threshold)}" placeholder="90" />
            </label>

            <label class="map-field">
              <span class="map-label">Severity</span>
              <select id="map-severity" class="map-select">
                ${["Info", "Warning", "Critical"].map((s) => `<option value="${s}" ${severity === s ? "selected" : ""}>${s}</option>`).join("")}
              </select>
            </label>

            <label class="map-field">
              <span class="map-label">Consecutive updates</span>
              <input id="map-consecutive" class="map-input map-num" type="number" min="1" step="1" value="${esc(consecutive)}" />
            </label>

            <label class="map-field">
              <span class="map-label">Cooldown (minutes)</span>
              <input id="map-cooldown" class="map-input map-num" type="number" min="0" step="1" value="${esc(cooldown)}" />
            </label>

            <label class="map-check">
              <input id="map-enabled" type="checkbox" ${enabled ? "checked" : ""} />
              <span>Policy enabled</span>
            </label>

            <div class="map-preview">
              <span class="map-label">Policy preview</span>
              <strong>${esc(preview)}</strong>
              <small>Scope: ${esc(metricSummary)}. New matching appliances inherit automatically.</small>
            </div>

            <div class="map-form__actions">
              <button type="submit" class="map-btn map-btn--primary" ${state.saving ? "disabled" : ""}>
                ${state.saving ? "Saving…" : state.editing ? "Update policy" : "Save & apply to all appliances"}
              </button>
            </div>
          </form>

          <aside class="map-inheritance" aria-label="How metric policies inherit">
            <div class="map-inheritance__title">Inheritance</div>
            <div class="map-rail">
              <div class="map-rail__node"><span>1</span><div><b>Select one metric</b><small>Example: CPU Utilization</small></div></div>
              <div class="map-rail__line"></div>
              <div class="map-rail__node"><span>2</span><div><b>Set its own condition</b><small>CPU can be high; memory can be low.</small></div></div>
              <div class="map-rail__line"></div>
              <div class="map-rail__node"><span>3</span><div><b>Apply everywhere</b><small>Current and future appliances inherit it.</small></div></div>
            </div>
            <div class="map-example">
              <div><span>CPU Utilization</span><b class="map-up">↑ &gt; 90</b></div>
              <div><span>Memory Available</span><b class="map-down">↓ &lt; 15</b></div>
            </div>
          </aside>
        </div>

        <div class="map-policies">
          <div class="map-policies__head">
            <div>
              <span class="map-eyebrow">MANAGED POLICIES</span>
              <h3>Inherited across appliances</h3>
            </div>
            <button type="button" class="map-btn map-btn--ghost" data-action="refresh">Refresh</button>
          </div>
          ${state.loading ? '<div class="map-empty">Loading metric policies…</div>' : policies.length === 0 ? '<div class="map-empty">No persistent metric policies yet. Create one above.</div>' : `
          <div class="map-tablewrap">
            <table class="map-table">
              <thead><tr><th>Metric</th><th>Condition</th><th>Severity</th><th>Scope</th><th>Status</th><th><span class="sr-only">Actions</span></th></tr></thead>
              <tbody>
                ${policies.map((p) => {
                  const m = exactMetric(p.metric_match);
                  const pattern = isPattern(p.metric_match);
                  const scope = m ? `${m.appliance_count} appliances` : pattern ? `${p.matches} matching metrics` : `${p.matches} appliances`;
                  return `<tr>
                    <td><div class="map-metricname">${esc(p.metric_match)}</div>${pattern ? '<span class="map-sub">Advanced pattern</span>' : '<span class="map-sub">Exact metric</span>'}</td>
                    <td><span class="map-condition ${p.operator.startsWith("<") ? "is-low" : "is-high"}"><b>${operatorGlyph[p.operator] || "•"}</b>${esc(conditionText(p))}</span></td>
                    <td><span class="map-sev ${severityClass(p.severity)}">${esc(p.severity)}</span></td>
                    <td class="map-num">${esc(scope)}</td>
                    <td>${statusBadge(p)}</td>
                    <td class="map-actions">
                      ${pattern ? "" : `<button type="button" class="map-link" data-action="edit" data-id="${esc(p.id)}">Edit</button>`}
                      <button type="button" class="map-link" data-action="toggle" data-id="${esc(p.id)}">${p.enabled ? "Disable" : "Enable"}</button>
                      <button type="button" class="map-link map-link--danger" data-action="delete" data-id="${esc(p.id)}">Delete</button>
                    </td>
                  </tr>`;
                }).join("")}
              </tbody>
            </table>
          </div>`}
        </div>
      </div>`;

    bind(root);
  }

  function formValues() {
    const metric = document.getElementById("map-metric")?.value.trim() || "";
    const operator = document.querySelector('input[name="map-operator"]:checked')?.value || ">";
    const thresholdRaw = document.getElementById("map-threshold")?.value.trim() || "";
    const severity = document.getElementById("map-severity")?.value || "Warning";
    const consecutive = Number(document.getElementById("map-consecutive")?.value || 1);
    const cooldown = Number(document.getElementById("map-cooldown")?.value || 0);
    const enabled = Boolean(document.getElementById("map-enabled")?.checked);
    return { metric, operator, thresholdRaw, severity, consecutive, cooldown, enabled };
  }

  function updatePreview() {
    const { metric, operator, thresholdRaw, severity, consecutive } = formValues();
    const m = exactMetric(metric);
    const summary = m
      ? `${m.appliance_count} ${m.appliance_count === 1 ? "appliance" : "appliances"} · ${m.account_count} ${m.account_count === 1 ? "account" : "accounts"}`
      : metric ? "Choose an exact metric from the catalog." : "Select a metric to see its scope.";
    const scope = document.getElementById("map-metric-scope");
    if (scope) scope.textContent = summary;
    const preview = document.querySelector(".map-preview strong");
    const detail = document.querySelector(".map-preview small");
    if (preview) preview.textContent = metric && thresholdRaw !== "" ? `${metric} ${operator} ${thresholdRaw} · ${severity} · ${consecutive} ${consecutive === 1 ? "update" : "updates"}` : "Choose a metric, condition and threshold.";
    if (detail) detail.textContent = `Scope: ${summary}. New matching appliances inherit automatically.`;
    document.querySelectorAll(".map-direction__option").forEach((label) => {
      label.classList.toggle("is-on", Boolean(label.querySelector("input")?.checked));
    });
  }

  function bind(root) {
    root.querySelector("#map-policy-form")?.addEventListener("submit", savePolicy);
    root.querySelectorAll("#map-policy-form input, #map-policy-form select").forEach((el) => {
      el.addEventListener("input", updatePreview);
      el.addEventListener("change", updatePreview);
    });
    root.querySelectorAll("[data-action]").forEach((button) => button.addEventListener("click", onAction));
  }

  async function savePolicy(event) {
    event.preventDefault();
    if (state.saving) return;
    const v = formValues();
    state.error = "";
    state.success = "";

    const metric = exactMetric(v.metric);
    if (!metric) {
      state.error = "Choose an exact metric from the BAMS metric catalog.";
      render();
      return;
    }
    const threshold = Number(v.thresholdRaw);
    if (v.thresholdRaw === "" || !Number.isFinite(threshold)) {
      state.error = "Enter a valid threshold.";
      render();
      return;
    }
    if (!Number.isInteger(v.consecutive) || v.consecutive < 1) {
      state.error = "Consecutive updates must be 1 or greater.";
      render();
      return;
    }
    if (!Number.isInteger(v.cooldown) || v.cooldown < 0) {
      state.error = "Cooldown must be 0 or greater.";
      render();
      return;
    }

    const body = {
      name: state.editing?.name || policyName(metric.metric_name, v.operator, threshold, v.severity),
      metric_match: metric.metric_name,
      rule_type: "fixed_threshold",
      operator: v.operator,
      threshold,
      reference_period: null,
      consecutive_updates: v.consecutive,
      severity: v.severity,
      cooldown_minutes: v.cooldown,
      enabled: v.enabled,
      auto_apply: true,
    };
    if (state.editing) {
      body.id = state.editing.id;
      body.expected_row_version = state.editing.row_version;
      body.name = state.editing.name;
    }

    state.saving = true;
    render();
    try {
      await api("/bams/configs/save", { method: "POST", body: JSON.stringify(body) });
      state.success = `${metric.metric_name} policy ${state.editing ? "updated" : "saved"}. It now applies to ${metric.appliance_count} ${metric.appliance_count === 1 ? "appliance" : "appliances"} and will inherit to future matching appliances.`;
      state.editing = null;
      await loadData(false);
    } catch (err) {
      state.error = err?.message || "Could not save the metric policy.";
    } finally {
      state.saving = false;
      render();
    }
  }

  async function togglePolicy(policy) {
    await api("/bams/configs/save", {
      method: "POST",
      body: JSON.stringify({
        id: policy.id,
        expected_row_version: policy.row_version,
        enabled: !policy.enabled,
        auto_apply: true,
      }),
    });
    state.success = `${policy.metric_match} policy ${policy.enabled ? "disabled" : "enabled"}.`;
    await loadData(false);
  }

  async function deletePolicy(policy) {
    if (!window.confirm(`Delete the persistent policy for ${policy.metric_match}? Managed rules will be disabled and alert history will be kept.`)) return;
    await api("/bams/configs/delete", {
      method: "POST",
      body: JSON.stringify({ id: policy.id, confirm: true }),
    });
    state.success = `${policy.metric_match} policy deleted. Existing managed rules were disabled; alert history was preserved.`;
    if (state.editing?.id === policy.id) state.editing = null;
    await loadData(false);
  }

  async function onAction(event) {
    const action = event.currentTarget.dataset.action;
    const id = event.currentTarget.dataset.id;
    state.error = "";
    if (action === "toggle-advanced") {
      state.advancedVisible = !state.advancedVisible;
      render();
      return;
    }
    if (action === "cancel-edit") {
      state.editing = null;
      render();
      return;
    }
    if (action === "refresh") {
      await loadData(true);
      return;
    }
    const policy = state.policies.find((p) => p.id === id);
    if (!policy) return;
    try {
      if (action === "edit") {
        state.editing = { ...policy };
        state.success = "";
        render();
        document.getElementById(ROOT_ID)?.scrollIntoView({ behavior: "smooth", block: "start" });
      } else if (action === "toggle") {
        await togglePolicy(policy);
        render();
      } else if (action === "delete") {
        await deletePolicy(policy);
        render();
      }
    } catch (err) {
      state.error = err?.message || "The metric policy action failed.";
      render();
    }
  }

  async function loadData(showLoading = true) {
    if (!isConfigPage()) return;
    if (showLoading) {
      state.loading = true;
      state.error = "";
      render();
    }
    try {
      const [catalog, configs] = await Promise.all([
        api("/bams/metrics/catalog"),
        api("/bams/configs"),
      ]);
      state.catalog = catalog.items || [];
      state.policies = configs.items || [];
    } catch (err) {
      state.error = err?.message || "Could not load metric policies.";
    } finally {
      state.loading = false;
      render();
    }
  }

  let scheduled = false;
  let lastRoute = "";
  function scheduleMount() {
    if (scheduled) return;
    scheduled = true;
    requestAnimationFrame(() => {
      scheduled = false;
      const route = window.location.pathname;
      if (!isConfigPage()) {
        document.getElementById(ROOT_ID)?.remove();
        lastRoute = route;
        return;
      }
      const page = findPage();
      if (!page) return;
      if (route !== lastRoute || !document.getElementById(ROOT_ID)) {
        lastRoute = route;
        render();
        loadData(true);
      } else {
        const legacy = findLegacyPanel(page);
        if (legacy) legacy.hidden = !state.advancedVisible;
      }
    });
  }

  ["pushState", "replaceState"].forEach((name) => {
    const original = history[name];
    history[name] = function (...args) {
      const result = original.apply(this, args);
      scheduleMount();
      return result;
    };
  });
  window.addEventListener("popstate", scheduleMount);
  window.addEventListener("DOMContentLoaded", scheduleMount, { once: true });

  const observer = new MutationObserver(scheduleMount);
  observer.observe(document.documentElement, { childList: true, subtree: true });
  scheduleMount();
})();
