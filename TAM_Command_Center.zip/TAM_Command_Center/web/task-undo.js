(() => {
  "use strict";

  // Lightweight integration layer: observes successful task-completion API calls
  // and offers an immediate, exact undo without modifying the compiled React bundle.
  const nativeFetch = window.fetch.bind(window);
  const UNDO_MS = 20000;
  let active = null;
  let timer = null;

  function ensureStyles() {
    if (document.getElementById("tam-task-undo-style")) return;
    const style = document.createElement("style");
    style.id = "tam-task-undo-style";
    style.textContent = `
      .tam-task-undo {
        position: fixed; right: 24px; bottom: 24px; z-index: 10000;
        width: min(440px, calc(100vw - 32px));
        display: grid; grid-template-columns: 1fr auto auto; align-items: center; gap: 12px;
        padding: 12px 12px 12px 14px;
        background: var(--surface-2, #171c24); color: var(--text, #e6e9ee);
        border: 1px solid var(--border-strong, #3d4a5c);
        border-left: 3px solid var(--success, #3fc77f);
        border-radius: var(--r-md, 4px); box-shadow: var(--shadow-pop, 0 8px 24px rgba(0,0,0,.5));
        font: 13px/20px var(--font-sans, "Segoe UI", sans-serif);
      }
      .tam-task-undo__copy { min-width: 0; }
      .tam-task-undo__title { display: block; font-weight: 600; }
      .tam-task-undo__task { display: block; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; color: var(--muted, #9aa3b0); }
      .tam-task-undo__action {
        height: 28px; padding: 0 10px; border: 1px solid var(--accent, #fa9a28);
        border-radius: var(--r-sm, 2px); background: var(--accent-tint, rgba(250,154,40,.12));
        color: var(--accent-hover, #ffb052); font-weight: 600; cursor: pointer;
      }
      .tam-task-undo__action:hover { background: var(--accent, #fa9a28); color: var(--on-accent, #0b0d10); }
      .tam-task-undo__action:focus-visible, .tam-task-undo__close:focus-visible { outline: 2px solid var(--focus, #7cc4ff); outline-offset: 2px; }
      .tam-task-undo__action:disabled { opacity: .55; cursor: wait; }
      .tam-task-undo__close { width: 28px; height: 28px; display: grid; place-items: center; color: var(--muted, #9aa3b0); cursor: pointer; }
      .tam-task-undo__close:hover { color: var(--text, #e6e9ee); background: var(--surface-3, #1f2630); }
      .tam-task-undo--error { border-left-color: var(--danger, #ff5c5c); }
      @media (max-width: 640px) { .tam-task-undo { right: 16px; bottom: 16px; } }
      @media (prefers-reduced-motion: no-preference) {
        .tam-task-undo { animation: tam-undo-in .12s ease-out; }
        @keyframes tam-undo-in { from { opacity: 0; transform: translateY(8px); } to { opacity: 1; transform: none; } }
      }
    `;
    document.head.appendChild(style);
  }

  function clearUndo() {
    if (timer) window.clearTimeout(timer);
    timer = null;
    active = null;
    document.getElementById("tam-task-undo")?.remove();
  }

  function renderUndo(record) {
    ensureStyles();
    clearUndo();
    active = record;

    const el = document.createElement("div");
    el.id = "tam-task-undo";
    el.className = "tam-task-undo";
    el.setAttribute("role", "status");
    el.setAttribute("aria-live", "polite");

    const copy = document.createElement("div");
    copy.className = "tam-task-undo__copy";
    const title = document.createElement("span");
    title.className = "tam-task-undo__title";
    title.textContent = "Task marked complete";
    const task = document.createElement("span");
    task.className = "tam-task-undo__task";
    task.textContent = record.task || "Task";
    copy.append(title, task);

    const button = document.createElement("button");
    button.type = "button";
    button.className = "tam-task-undo__action";
    button.textContent = "Undo";
    button.title = "Restore the task to its previous status (Ctrl/Cmd+Z)";
    button.addEventListener("click", () => undo(record, el, button));

    const close = document.createElement("button");
    close.type = "button";
    close.className = "tam-task-undo__close";
    close.setAttribute("aria-label", "Dismiss undo");
    close.title = "Dismiss";
    close.textContent = "×";
    close.addEventListener("click", clearUndo);

    el.append(copy, button, close);
    document.body.appendChild(el);
    timer = window.setTimeout(clearUndo, UNDO_MS);
  }

  async function undo(record, el, button) {
    if (!active || active.id !== record.id) return;
    button.disabled = true;
    button.textContent = "Undoing…";
    try {
      const response = await nativeFetch("/api/task/undo-complete", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id: record.id, expected_row_version: record.rowVersion })
      });
      const payload = await response.json().catch(() => ({}));
      if (!response.ok || payload.ok === false) {
        const message = payload?.error?.message || payload?.message || "Could not undo task completion.";
        throw new Error(message);
      }
      const restored = payload?.item?.status || "previous status";
      if (timer) window.clearTimeout(timer);
      timer = null;
      active = null;
      el.querySelector(".tam-task-undo__title").textContent = `Restored to ${restored}`;
      el.querySelector(".tam-task-undo__task").textContent = record.task || "Task";
      button.remove();
      window.setTimeout(() => window.location.reload(), 450);
    } catch (error) {
      el.classList.add("tam-task-undo--error");
      el.querySelector(".tam-task-undo__title").textContent = "Undo failed";
      el.querySelector(".tam-task-undo__task").textContent = error instanceof Error ? error.message : "Reload and try again.";
      button.disabled = false;
      button.textContent = "Retry";
    }
  }

  function requestDetails(input, init) {
    try {
      const url = typeof input === "string" ? input : input?.url;
      if (!url) return null;
      const parsed = new URL(url, window.location.href);
      if (parsed.pathname !== "/api/task/save") return null;
      const method = String(init?.method || (typeof input !== "string" ? input?.method : "GET") || "GET").toUpperCase();
      if (method !== "POST") return null;
      if (typeof init?.body !== "string") return null;
      const body = JSON.parse(init.body);
      if (!body?.id || body.status !== "Complete") return null;
      return { id: body.id, task: body.task || "Task" };
    } catch {
      return null;
    }
  }

  window.fetch = async function tamUndoFetch(input, init) {
    const completion = requestDetails(input, init);
    const response = await nativeFetch(input, init);
    if (completion && response.ok) {
      try {
        const payload = await response.clone().json();
        const rowVersion = payload?.item?.row_version;
        if (Number.isInteger(rowVersion) && rowVersion > 0) {
          renderUndo({ ...completion, rowVersion });
        }
      } catch {
        // The normal request has already succeeded; never break app flow just
        // because the optional Undo UI could not read the cloned response.
      }
    }
    return response;
  };

  window.addEventListener("keydown", (event) => {
    if (!active || event.defaultPrevented || !(event.ctrlKey || event.metaKey) || event.key.toLowerCase() !== "z") return;
    const target = event.target;
    if (target instanceof HTMLInputElement || target instanceof HTMLTextAreaElement || target?.isContentEditable) return;
    const el = document.getElementById("tam-task-undo");
    const button = el?.querySelector(".tam-task-undo__action");
    if (!el || !button) return;
    event.preventDefault();
    undo(active, el, button);
  });
})();
