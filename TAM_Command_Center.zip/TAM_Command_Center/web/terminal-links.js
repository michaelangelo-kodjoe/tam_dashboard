(function (global) {
  "use strict";

  const TOKEN_RE = /\{([^{}\r\n]{1,240})\}/g;
  const LINK_CLASS = "bbg-terminal-link";
  const SKIP_SELECTOR = [
    "a",
    "input",
    "textarea",
    "select",
    "option",
    "code",
    "pre",
    "script",
    "style",
    "template",
    '[contenteditable="true"]',
    "[data-no-bbg-links]",
    ".bbg-terminal-link",
  ].join(",");

  function normalizeCommand(raw) {
    return String(raw || "")
      .replace(/<\s*go\s*>/gi, "")
      .replace(/\s+/g, " ")
      .trim();
  }

  function toScreenUrl(raw) {
    const command = normalizeCommand(raw);
    return command ? `bbg://screens/${encodeURIComponent(command)}` : "";
  }

  function hasTerminalToken(text) {
    TOKEN_RE.lastIndex = 0;
    return TOKEN_RE.test(String(text || ""));
  }

  function shouldSkip(node) {
    const parent = node && node.parentElement;
    if (!parent) return true;
    if (!parent.closest("#root")) return true;
    return Boolean(parent.closest(SKIP_SELECTOR));
  }

  function makeLink(doc, displayText, rawCommand) {
    const command = normalizeCommand(rawCommand);
    if (!command) return doc.createTextNode(displayText);

    const link = doc.createElement("a");
    link.className = LINK_CLASS;
    link.href = toScreenUrl(command);
    link.textContent = displayText;
    link.dataset.bbgCommand = command;
    link.title = `Open ${command} in Bloomberg Terminal`;
    link.setAttribute("aria-label", `${displayText} — open in Bloomberg Terminal`);
    link.addEventListener("click", function (event) {
      // Do not let a Terminal link also trigger a clickable task/table row.
      event.stopPropagation();
    });
    return link;
  }

  function linkifyTextNode(node) {
    if (!node || node.nodeType !== 3 || shouldSkip(node)) return false;

    const text = node.nodeValue || "";
    if (!hasTerminalToken(text)) return false;

    TOKEN_RE.lastIndex = 0;
    const matches = Array.from(text.matchAll(TOKEN_RE));
    if (!matches.length) return false;

    const doc = node.ownerDocument;
    const fragment = doc.createDocumentFragment();
    let cursor = 0;

    for (const match of matches) {
      const start = match.index || 0;
      if (start > cursor) {
        fragment.appendChild(doc.createTextNode(text.slice(cursor, start)));
      }

      const displayText = match[0];
      const rawCommand = match[1];
      fragment.appendChild(makeLink(doc, displayText, rawCommand));
      cursor = start + displayText.length;
    }

    if (cursor < text.length) {
      fragment.appendChild(doc.createTextNode(text.slice(cursor)));
    }

    node.replaceWith(fragment);
    return true;
  }

  function linkifyTree(root) {
    if (!root || !root.ownerDocument) return;

    const doc = root.ownerDocument;
    const walker = doc.createTreeWalker(root, global.NodeFilter.SHOW_TEXT);
    const nodes = [];
    let current;

    while ((current = walker.nextNode())) {
      nodes.push(current);
    }

    for (const node of nodes) linkifyTextNode(node);
  }

  function injectStyles(doc) {
    if (doc.getElementById("tam-bbg-terminal-link-styles")) return;

    const style = doc.createElement("style");
    style.id = "tam-bbg-terminal-link-styles";
    style.textContent = `
      .${LINK_CLASS} {
        color: var(--info, #5aaeff);
        text-decoration: none;
        border-bottom: 1px dotted currentColor;
        cursor: pointer;
        white-space: normal;
      }
      .${LINK_CLASS}::after {
        content: " ↗";
        font-size: 0.78em;
        opacity: 0.6;
      }
      .${LINK_CLASS}:hover {
        color: var(--accent, #fa9a28);
        border-bottom-style: solid;
        text-decoration: none;
      }
      .${LINK_CLASS}:focus-visible {
        outline: 2px solid var(--focus, #7cc4ff);
        outline-offset: 2px;
        border-radius: 2px;
      }
    `;
    doc.head.appendChild(style);
  }

  function start(doc) {
    const root = doc.getElementById("root");
    if (!root) return;

    injectStyles(doc);
    linkifyTree(root);

    const observer = new MutationObserver(function (mutations) {
      for (const mutation of mutations) {
        if (mutation.type === "characterData") {
          linkifyTextNode(mutation.target);
          continue;
        }

        for (const added of mutation.addedNodes) {
          if (added.nodeType === 3) {
            linkifyTextNode(added);
          } else if (added.nodeType === 1 && !added.matches(`.${LINK_CLASS}`)) {
            linkifyTree(added);
          }
        }
      }
    });

    observer.observe(root, {
      subtree: true,
      childList: true,
      characterData: true,
    });
  }

  global.TAMTerminalLinks = Object.freeze({
    normalizeCommand,
    toScreenUrl,
    hasTerminalToken,
  });

  if (global.document) {
    if (global.document.readyState === "loading") {
      global.document.addEventListener("DOMContentLoaded", function () {
        start(global.document);
      }, { once: true });
    } else {
      start(global.document);
    }
  }
})(typeof window !== "undefined" ? window : globalThis);
